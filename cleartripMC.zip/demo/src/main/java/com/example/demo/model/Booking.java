package com.example.demo.model;

public class Booking {
    private long id;
    private User user;

    private
}
